package HttpLoggingInterceptor.Level;

public class BODY {
}
