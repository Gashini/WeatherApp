package com.example.weather;

import android.location.Geocoder;
import android.location.Address;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView tvCoordinates;
    private TextView tvAddress;
    private TextView tvTime;
    private TextView tvWeather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCoordinates = findViewById(R.id.tvCoordinates);
        tvAddress = findViewById(R.id.tvAddress);
        tvTime = findViewById(R.id.tvTime);
        tvWeather = findViewById(R.id.tvWeather);

        double latitude = 6.0441;
        double longitude = 80.2511;

        tvCoordinates.setText("Lat: " + latitude + ", Lon: " + longitude);
        tvTime.setText("Current Time: " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));

        getWeatherData(latitude, longitude);
        getAddress(latitude, longitude);
    }
    private void getWeatherData(double lat, double lon) {
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build();

        WeatherService weatherService = retrofit.create(WeatherService.class);

        Call<WeatherResponse> call = weatherService.getCurrentWeather(lat, lon, "16c2ab3566ef6b743455f314d26530dd", "metric");
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful()) {
                    WeatherResponse weatherResponse = response.body();
                    if (weatherResponse != null) {
                        String weatherInfo = "Temperature: " + weatherResponse.getMain().getTemp() + "°C\n" +
                                "Humidity: " + weatherResponse.getMain().getHumidity() + "%\n" +
                                "Description: " + weatherResponse.getWeather().get(0).getDescription();
                        tvWeather.setText(weatherInfo);
                    }
                } else {
                    tvWeather.setText("Failed to retrieve weather data");
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                tvWeather.setText("Failed to retrieve weather data");
            }
        });
    }

    private void getAddress(double lat, double lon) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        new Thread(() -> {
            try {
                List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    runOnUiThread(() -> tvAddress.setText(address.getAddressLine(0)));
                } else {
                    runOnUiThread(() -> tvAddress.setText("Failed to retrieve address"));
                }
            } catch (IOException e) {
                runOnUiThread(() -> tvAddress.setText("Failed to retrieve address"));
            }
        }).start();
    }
}